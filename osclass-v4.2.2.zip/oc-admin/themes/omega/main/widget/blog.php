<?php if ( ! defined('OC_ADMIN')) exit('Direct access is not allowed.');
/*
 * Copyright 2020 OsclassPoint.com
 *
 * Osclass maintained & developed by OsclassPoint.com
 * you may not use this file except in compliance with the License.
 * You may download copy of Osclass at
 *
 *     https://osclass-classifieds.com/download
 *
 * Software is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */


$articles = osc_file_get_contents(osc_market_url('blog'));
$articles  = json_decode($articles, true);
?>

<?php if(count($articles) <= 0) { ?>
  <div class="empty"><?php _e('No articles has been found'); ?></div>
<?php } else { ?>
  <?php foreach($articles as $a) { ?>
    <div class="row">
      <a href="<?php echo $a['link']; ?>"><?php echo $a['title']; ?></a>
      <div class="date"><?php echo osc_format_date($a['pub_date'], 'd. M Y'); ?></div>
      <div class="desc"><?php echo osc_highlight($a['short_description'], 135); ?></div>
    </div>
  <?php } ?>
<?php } ?>

<div class="foot">
  <a href="https://osclasspoint.com/blog/home"><?php _e('More news'); ?></a>
</div>
<?php if ( ! defined('OC_ADMIN')) exit('Direct access is not allowed.');
/*
 * Copyright 2020 OsclassPoint.com
 *
 * Osclass maintained & developed by OsclassPoint.com
 * you may not use this file except in compliance with the License.
 * You may download copy of Osclass at
 *
 *     https://osclass-classifieds.com/download
 *
 * Software is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */

$api_key = osc_get_preference('osclasspoint_api_key', 'osclass'); 
?>
  
<?php if($api_key == '') { ?>
  <div class="row"><?php _e('API key has not been defined'); ?></div>
  <div class="row"><?php echo sprintf(__('In order to be able to download data from OsclassPoint, you must define your API key in %s section'), '<a href="' . osc_admin_base_url(true) . '?page=settings">' . __('Settings > General > Software updates') . '</a>'); ?>.</div>
<?php } else { ?>
  <?php
    $data = osc_file_get_contents(osc_market_url('validate_api_key'));
    $data = json_decode($data, true); 
  ?>
  
  <?php if(isset($data['error']) && $data['error'] <> '') { ?>
    <div class="row"><?php echo sprintf(_m('API key validation error: %s'), $data['error']); ?>.</div>
  <?php } else { ?>
    <div class="row"><i class="fa fa-check-circle-o"></i> <?php _e('API key is valid, automatic updates & market functions are available'); ?>.</div>
  <?php } ?>
<?php } ?>
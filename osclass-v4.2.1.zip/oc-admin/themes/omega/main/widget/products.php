<?php if ( ! defined('OC_ADMIN')) exit('Direct access is not allowed.');
/*
 * Copyright 2020 OsclassPoint.com
 *
 * Osclass maintained & developed by OsclassPoint.com
 * you may not use this file except in compliance with the License.
 * You may download copy of Osclass at
 *
 *     https://osclass-classifieds.com/download
 *
 * Software is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */

$products_json = osc_file_get_contents('https://osclasspoint.com/oc-content/plugins/market/api/v3/products.php?sort=latest&limit=5&apiKey=' . osc_get_preference('osclasspoint_api_key', 'osclass'));
$products = json_decode($products_json, true);
?>

<?php if(count($products) <= 0) { ?>
  <div class="empty"><?php _e('No products has been found'); ?></div>
<?php } else { ?>
  <?php foreach($products as $p) { ?>
    <div class="row">
      <a href="<?php echo $p['s_url']; ?>"><?php echo $p['s_title']; ?></a>
      <div class="desc"><?php echo osc_highlight($p['s_description'], 120); ?></div>
    </div>
  <?php } ?>
<?php } ?>

<div class="foot">
  <a href="https://osclasspoint.com/search"><?php _e('More products'); ?></a>
</div>